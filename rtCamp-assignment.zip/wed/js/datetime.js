		
			
                function timer()
                {
                    var mytime = new Date(); // contructed child of Date object
            
                    var h = mytime.getHours();
                    var m = mytime.getMinutes();
                    var s = mytime.getSeconds();
            
                    var timestatus = null;
            
                    if(h > 12)
                    {
                        timestatus = "PM";
                    }
                    else
                    {
                        timestatus = "AM";
                    }
            
                    if(h > 12)
                    {
                        h = h - 12;
                    }
            
                    if(m < 10)
                    {
                        m = "0" + m;
                    }
            
                    if(s < 10)
                    {
                        s = "0" + s;
                    }
            
                    if(h == 0)
                    {
                        h = 12;
                    }
            
                    document.getElementById("mytime").innerHTML = h + ":" + m + ":" + s + timestatus;
            
                    setTimeout("timer()",1000);
                }
            
                timer();
				
				
				var mydate = new Date(); // contructed child of Date object
            
                var date = mydate.getDate();
                var month = mydate.getMonth();
                var year = mydate.getFullYear();
            
                month++;
            
                document.getElementById("mydate").innerHTML = date + "," + year;
            
				function timer1()
			{
				var mytime = new Date(); // contructed child of Date object

				var day = mytime.getDay();

				switch(day)
				{
					case 0:
					day = "Sunday";
					break;

					case 1:
					day = "Monday";
					break;

					case 2:
					day = "Tuesday";
					break;

					case 3:
					day = "Wednesday";
					break;

					case 4:
					day = "Thursday";
					break;

					case 5:
					day = "Friday";
					break;

					case 6:
					day = "Saturday";
					break;
				}

				
				document.getElementById("myDay").innerHTML = day;

				setTimeout("timer1()",1000);
			}

			timer1();
            
     